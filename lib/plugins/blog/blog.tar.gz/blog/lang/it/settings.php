<?php
/**
 * Italian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Niccolo Rigacci <niccolo@rigacci.org>
 */
 
// for the configuration manager
$lang['namespace']        = 'Namespace predefinito per il blog';

//Setup VIM: ex: et ts=2 enc=utf-8 :
