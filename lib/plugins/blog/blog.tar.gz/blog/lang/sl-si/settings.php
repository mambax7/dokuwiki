<?php
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Blaž Mertelj <Blaz.Mertelj@atol.si>
 */
 
// for the configuration manager
$lang['namespace']          = 'privzeti namespace za blog';

$lang['sortkey']            = 'sortiraj blog vnose po:';
$lang['sortkey_o_cdate']    = 'ustvarjeno dne';
$lang['sortkey_o_pagename'] = 'ime strani';
$lang['sortkey_o_id']       = 'ID strani';

$lang['dateprefix']         = 'pripeti datum pred IDje novih vnosov';

//Setup VIM: ex: et ts=2 enc=utf-8 :