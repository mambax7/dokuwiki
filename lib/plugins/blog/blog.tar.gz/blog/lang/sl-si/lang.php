<?php
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Blaž Mertelj <Blaz.Mertelj@atol.si>
 */

// custom language strings for the plugin
$lang['blog']       = 'Blog';
$lang['older']      = 'Starejši vnosi'; 
$lang['newer']      = 'Novejši vnosi'; 
$lang['newentry']   = 'Nov blog vnos:'; 

//Setup VIM: ex: et ts=2 enc=utf-8 :