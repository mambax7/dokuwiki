<?php
/**
 * Hungarian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Norbert Csík <norbert.csik@gmail.com>
 */
 
// for the configuration manager
$lang['namespace']        = 'blog alapértelmezett névtere';

//Setup VIM: ex: et ts=2 enc=utf-8 :