<?php
/**
* Swedish language file
*
* @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
* @author     Christer Nygren <wiki@fronet.fro.se>
*/

// custom language strings for the plugin
$lang['blog']       = 'Blog';
$lang['older']      = 'Äldre inlägg';
$lang['newer']      = 'Nyare inlägg';
$lang['newentry']   = 'Nytt inlägg:';

//Setup VIM: ex: et ts=2 enc=utf-8 :