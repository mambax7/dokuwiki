<?php
/**
 * Swedish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Christer Nygren <wiki@fronet.fro.se>
 */

// for the configuration manager
$lang['namespace']          = 'standard vy för blog';

$lang['sortkey']            = 'sortera inlägg efter:';
$lang['sortkey_o_cdate']    = 'skapat datum';
$lang['sortkey_o_pagename'] = 'sidnamn';
$lang['sortkey_o_id']       = 'sid ID';

$lang['dateprefix']         = 'sätt datum före nytt inläggs ID';

//Setup VIM: ex: et ts=2 enc=utf-8 :