<?php
/**
 * Russian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Spike <Spike@Foobar2000.Ru>
 */

// custom language strings for the plugin
$lang['older']      = 'Предыдущие записи';
$lang['newer']      = 'Новые записи';
$lang['newentry']   = 'Новая запись в блоге:';

//Setup VIM: ex: et ts=2 enc=utf-8 :