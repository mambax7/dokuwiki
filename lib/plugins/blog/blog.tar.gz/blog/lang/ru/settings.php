<?php
/**
 * Russian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Spike <Spike@Foobar2000.Ru>
 */
 
// for the configuration manager
$lang['namespace']        = 'неймспейс по умолчанию для блога';

//Setup VIM: ex: et ts=2 enc=utf-8 :