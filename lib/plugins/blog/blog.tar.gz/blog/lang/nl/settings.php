<?php
/**
 * Dutch language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Gijs van Gemert <gijsh@sherpanet.nl>
 */
 
// for the configuration manager
$lang['namespace']        = 'default namespace voor blog';

//Setup VIM: ex: et ts=2 enc=utf-8 :