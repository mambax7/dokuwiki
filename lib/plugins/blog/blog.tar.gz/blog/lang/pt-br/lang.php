<?php
/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Flávio Roberto Santos <flavio.barata@gmail.com>
 */

// custom language strings for the plugin
$lang['older']      = 'registros antigos';
$lang['newer']      = 'registros mais novos';

//Setup VIM: ex: et ts=2 enc=utf-8 :
