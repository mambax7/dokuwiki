<?php
/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Flávio Roberto Santos <flavio.barata@gmail.com>
 */
 
// for the configuration manager
$lang['namespace']        = 'namespace padrão para o blog';

//Setup VIM: ex: et ts=2 enc=utf-8 :
