<?php
/**
 * Archivo en español
 *
 * @licence    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Herman Fabián Sandoval Manrique <hfsandovalm@emzac.com>
 */
 
// para el gestor de configuraciones (configuration manager)
$lang['namespace']        = 'namespace predeterminado para el blog';

//Setup VIM: ex: et ts=2 enc=utf-8 :
