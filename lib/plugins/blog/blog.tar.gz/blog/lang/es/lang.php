<?php
/**
 * Archivo en español
 *
 * @licence    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Herman Fabián Sandoval Manrique <hfsandovalm@emzac.com>
 */

// frases personalizadas en español para el plugin
$lang['older']      = 'Entradas anteriores';
$lang['newer']      = 'Entradas nuevas';
$lang['newentry']   = 'Nueva entrada en el blog:';

//Setup VIM: ex: et ts=2 enc=utf-8 :
